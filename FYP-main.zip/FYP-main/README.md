# FYP
run locally
set up mongodb and
configure next auth
NEXT_PUBLIC_HEROKU_URL=
https://disasteralert87-98501f8ad722.herokuapp.com/
get google maps api 

notifications
